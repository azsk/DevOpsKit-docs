# Standard configurations
# Link to the Azure Active Directory Authentication URL, ending with a '/'. Example: https://login.microsoftonline.com/
$AzureAdAuthUrl = "https://login.microsoftonline.com/"

# Link to the Graph API endpoint. Example: https://graph.microsoft.com
$GraphApi = "https://graph.microsoft.com"

# Link to a page, where issues seen in AzTS can be reported to the dev. team.
# For now, this will point to an "under construction" Wiki page on GitHub.
$IssueTrackerUrl = "https://aka.ms/AzTSIssueTracker"

# AzTS Support Mail. Example. mailto:aztssup@microsoft.com
$IssueSupportMail = "aztssup@microsoft.com"

# Default Baseline
$DefaultBaseline = "ActiveBaseline"

# Base URL to the Wiki, that has information about Controls and their remediation steps.
# For now, this will point to an "under construction" Wiki page on GitHub.
$ControlWikiBaseUrl = "https://aka.ms/AzTSControlRemediationWiki"

# Exception configurations
# A string indicating if support for raising exceptions to Controls, is available. "false", by default.
$IsExceptionsEnabled = "false"

# This specifies how/where non-ByDesign exceptions can be raised and tracked for compliance.
# Example(s): https://foo.exceptions, or "mailto:foo@bar.com"
$DefaultExceptionsTarget = "<replace-with-a-link-to-the-compliance-portal>"

function Configure-WebUI
{
    Param(
        [string]
        [Parameter(Mandatory = $true, HelpMessage="TenantID of the subscription where Azure Tenant Security Solution is to be installed.")]
        $TenantId,

        [string]
        [Parameter(Mandatory = $true, HelpMessage="Name of the Resource Group where setup resources will be created.")]
        $ScanHostRGName,

        [string]
        [Parameter(Mandatory = $true, HelpMessage="Name of the web app deployed in azure for Azure Tenant Security Solution.")]
        $WebAppName,

        [string]
        [Parameter(Mandatory = $true, HelpMessage="URL of the Web API")]
        $ApiUrl,

        [string]
        [Parameter(Mandatory = $true, HelpMessage="ClientId of the web app deployed in azure for Azure Tenant Security Solution.")]
        $WebAppClientId,

        [string]
        [Parameter(Mandatory = $true, HelpMessage="ClientId of the web api deployed in azure for Azure Tenant Security Solution.")]
        $WebApiClientId
    )

    Write-Host "Configuring AzTS UI..."
    
    $baseDir = Get-Location
    $configFile = "runtime-configuration.js"
    $configFilePath = "${baseDir}\${configFile}"
    $configJs = @"
window.__REACT_APP_RUNTIME_CONFIGURATION__ = {
    "tenantId": "$TenantId",
    "webAPI": "$ApiUrl",
    "clientId": "$WebAppClientId",
    "apiClientId": "$WebApiClientId",
    "azureADAuthURL": "$AzureAdAuthUrl",
    "graphAPI": "$GraphApi",
    "issueTrackerURL": "$IssueTrackerUrl",
    "issueSupportMail": "$IssueSupportMail",
    "defaultBaseline": "$DefaultBaseline",
    "controlWikiBaseURL": "$ControlWikiBaseUrl",
    "Baselines": [
        {
            "name": "foo",
            "controlFilterLabel": "Foo Baseline Controls Only",
            "isControlFilterToggleEnabled": true,
            "isExceptionsEligible": true,
            "exceptionTarget": "mailto:xyz@foo.bar"
        },
        {
            "name": "bar",                
            "isExceptionsEligible": true
        },
    ],
    "Exceptions": {
        "isEnabled": $IsExceptionsEnabled,
        "defaultExceptionTarget": "$DefaultExceptionsTarget",
        "CustomType": {
            "key": "<key-associated-with-the-exception-type. Example: mycustomtype>",
            "text": "<label-associated-with-the-exception. Example: mycustomtype>",
            "data": "<type-of-the-exception. Example: My Custom Type>",
            "disabled": false            
        }
    }
}
"@

    $configJs | Set-Content $configFilePath

    $webApp = Get-AzWebApp -Name $WebAppName -ResourceGroupName $ScanHostRGName
    [xml]$publishingProfile = Get-AzWebAppPublishingProfile -WebApp $webApp
    $username = $publishingProfile.publishData.publishProfile[0].userName
    $password = $publishingProfile.publishData.publishProfile[0].userPWD
    $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $username, $password)))
    $userAgent = "powershell/1.0"
    
    $uploadUrl = "https://${WebAppName}.scm.azurewebsites.net/api/vfs/site/wwwroot/${configFile}"
    Invoke-RestMethod -Uri $uploadUrl -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -UserAgent $userAgent -Method PUT -InFile $configFilePath -ContentType "multipart/form-data"

    Reset-AzWebAppPublishingProfile -Name $WebAppName -ResourceGroupName $ScanHostRGName
    
    If((test-path $configFilePath))
    {
        Remove-Item -Force -Path $configFilePath
    }
}