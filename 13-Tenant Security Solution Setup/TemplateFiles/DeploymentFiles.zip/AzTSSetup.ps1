﻿
function Install-AzSKTenantSecuritySolution
{
    <#
	.SYNOPSIS
	This command would help in installing Azure Tenant Security Solution in your subscription. 
	.DESCRIPTION
	This command will install an Azure Tenant Security Solution which runs security scan on subscription in a Tenant.
	Security scan results will be populated in Log Analytics workspace and Azure Storage account which is configured during installation.  
	
	.PARAMETER SubscriptionId
		Subscription id in which Azure Tenant Security Solution needs to be installed.
	.PARAMETER ScanHostRGName
		Name of ResourceGroup where setup resources will be created. 
	.PARAMETER Location
		Location where all resources will get created. Default location is EastUS2.
	.PARAMETER ScanIdentityId
		Resource id of user managed identity used to scan subscriptions. 
    .PARAMETER TemplateFilePath
        Comma separated Application resource group names on which security scan should be performed by Azure Tenant Security Solution.
     .PARAMETER TemplateParameters
        Comma separated Application resource group names on which security scan should be performed by Azure Tenant Security Solution.
    .NOTES
	

	.LINK
	https://aka.ms/azskossdocs 

	#>
    Param(
        
        [string]
        [Parameter(Mandatory = $true, HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        $SubscriptionId,

        [string]
		[Parameter(Mandatory = $false, HelpMessage="Name of ResourceGroup where setup resources will be created.")]
		$ScanHostRGName = "AzSK-AzTS-RG",

        [string]
        [Parameter(Mandatory = $true, HelpMessage="Location where all resources will get created. Default location is EastUS2.")]
        $Location,

        [string]
        [Parameter(Mandatory = $true, HelpMessage="Resource id of user managed identity used to scan subscriptions.")]
        $ScanIdentityId,

        [string]
        [Parameter(Mandatory = $false)]
        $TemplateFilePath = ".\AzTSDeploymentTemplate.json",

        [Hashtable]
        [Parameter(Mandatory = $false)]
        $TemplateParameters = @{},

        [switch]
        [Parameter(Mandatory = $false, HelpMessage="Usage telemetry captures anonymous usage data and sends it to Microsoft servers. This will help in improving the product quality and prioritize meaning fully on the highly used features.")]
        $SendUsageTelemetry = $false,

        [switch]
        [Parameter(Mandatory = $false, HelpMessage="Specify if user managed identity has Graph permission. This is to exclude controls dependent on Graph API reponse from the scan result, if scanner identity does not have graph permission.")]
        $ScanIdentityHasGraphPermission = $false
    )
        Begin
        {
            $currentContext = $null
            $contextHelper = [ContextHelper]::new()
            $currentContext = $contextHelper.SetContext($SubscriptionId)
            if(-not $currentContext)
            {
                return;
            }
        }

        Process
        {
            # Load all other scripts that are required by this script.
            . "$PSScriptRoot\ConfigureWebUI.ps1"

            Write-Host $([Constants]::DoubleDashLine)
            Write-Host "Running Azure Tenant Security Solution setup...`n" -ForegroundColor $([Constants]::MessageType.Info)
            Write-Host $([Constants]::InstallSolutionInstructionMsg ) -ForegroundColor $([Constants]::MessageType.Info)
            Write-Host $([Constants]::SingleDashLine)
            
            
            Write-Host "`r`nStarted setting up Azure Tenant Security Solution. This may take 5 mins..." -ForegroundColor $([Constants]::MessageType.Info)
           
            # Create resource group if not exist
            try
            {
                Write-Verbose "$(Get-TimeStamp)Checking resource group for deployment..." #-ForegroundColor $([Constants]::MessageType.Info)
                $rg = Get-AzResourceGroup -Name $ScanHostRGName -ErrorAction SilentlyContinue
                if(-not $rg)
                {
                    Write-Verbose "$(Get-TimeStamp)Creating resource group for deployment..." #-ForegroundColor $([Constants]::MessageType.Info)
                    $rg = New-AzResourceGroup -Name $ScanHostRGName -Location $Location -ErrorAction Stop
                }
                else{
                    Write-Verbose "$(Get-TimeStamp)Resource group already exists." #-ForegroundColor $([Constants]::MessageType.Info)
                }
                
            }
            catch
            {  
                Write-Host "`n`rFailed to create resource group for deployment." -ForegroundColor $([Constants]::MessageType.Error)
                return;
            }
                        
	        # start arm template deployment
            try
            {
                # Set usage telemetry log type based on input provided by the user
                if($SendUsageTelemetry)
                {
                    $TemplateParameters.Add("AnonymousUsageTelemetryLogLevel", "Anonymous")
                }
                else
                {
                    $TemplateParameters.Add("AnonymousUsageTelemetryLogLevel", "None")
                }

                # Select rule based on graph permission.
                if($ScanIdentityHasGraphPermission)
                {
                    $TemplateParameters.Add("RuleEngineWorkflowName", "FullTenantScan")
                }
                else
                {
                    $TemplateParameters.Add("RuleEngineWorkflowName", "FullTenantScanExcludeGraph")
                }

                # if($TemplateParameters.Count -eq 0)
                # {
                #     Write-Host "`n`rPlease enter the parameter required for template deployment:" -ForegroundColor $([Constants]::MessageType.Info)   
                #     Write-Host "Note: Alternatively you can use '-TemplateParameters' to pass these parameters.`n`r"  -ForegroundColor $([Constants]::MessageType.Warning)   
                # }
                $ResourceId='/subscriptions/{0}/resourceGroups/{1}' -f $SubscriptionId,$ScanHostRGName;
                $ResourceIdHash = get-hash($ResourceId)
                $ResourceHash = $ResourceIdHash.Substring(0,5).ToString().ToLower() #considering only first 5 characters
                $AnonymousUsageTelemetryId = $ResourceIdHash.Substring(0,16).ToString().ToLower()

                #adding ResourceHash to TemplateParameters
                $TemplateParameters.Add("AnonymousUsageTelemetryId", $AnonymousUsageTelemetryId)
                $TemplateParameters.Add("ResourceHash", $ResourceHash)
                $TemplateParameters.Add("MIResourceId", $ScanIdentityId)
                #Get the tenant Id from the current subscription contex
                $context=Get-AzContext
                $TemplateParameters.Add("TenantId", $context.Tenant.Id)

                # Name of the Web api to be created in azure aad registration
                $webApiName="AzSK-AzTS-WebApi-$ResourceHash"
                $webApi = CreateChildApp -displayName $webApiName
                # Need to create service principle of webapp
                #$spWebApi = Get-AzureADServicePrincipal -Filter "DisplayName eq '$($webApiName)'"
                $spWebApi = Get-AzureADServicePrincipal -Filter "AppId eq '$($webApi.AppId)'"
                $TemplateParameters.Add("WebApiClientId", $webApi.AppId)


                # TODO: Check this is required or not. Permission that need to be assigned to the web app
                # MS Graph permission
                $appPermissionsRequired = @('openid','profile','User.Read','email','User.ReadBasic.All', 'User.Read.All', 'Directory.Read.All')
                $targetServicePrincipalAppId='00000003-0000-0000-c000-000000000000'
                #$targetServicePrincipalName = 'Microsoft Graph'
                #$msGraphAad=GrantAllThePermissionsWeWant -targetServicePrincipalName $targetServicePrincipalName -appPermissionsRequired $appPermissionsRequired -childApp $webApi -spForApp $spWebApi
                $msGraphAad=GrantAllThePermissionsWeWant -targetServicePrincipalAppId $targetServicePrincipalAppId -appPermissionsRequired $appPermissionsRequired -childApp $webApi -spForApp $spWebApi
               
                Set-AzureADApplication -ObjectId $webApi.ObjectId -RequiredResourceAccess $msGraphAad
                
                # Name of the Web app to be created in azure aad registration
                $webAppName="AzSK-AzTS-WebApp-$ResourceHash"
                $webApp = CreateChildApp -displayName $webAppName
                # Need to create service principle of webapp
                #$spWebApp = Get-AzureADServicePrincipal -Filter "DisplayName eq '$($webAppName)'"
                $spWebApp = Get-AzureADServicePrincipal -Filter "AppId eq '$($webApp.AppId)'"
                $TemplateParameters.Add("WebAppClientId", $webApp.AppId)

                #Permission that need to be assigned to the web app
                # MS Graph permission
                $appPermissionsRequired = @('openid','profile','User.Read','email','User.ReadBasic.All')
                $targetServicePrincipalAppId='00000003-0000-0000-c000-000000000000'
                #$targetServicePrincipalName = 'Microsoft Graph'
                #$msGraphAad=GrantAllThePermissionsWeWant -targetServicePrincipalName $targetServicePrincipalName -appPermissionsRequired $appPermissionsRequired -childApp $webApp -spForApp $spWebApp
                $msGraphAad=GrantAllThePermissionsWeWant -targetServicePrincipalAppId $targetServicePrincipalAppId -appPermissionsRequired $appPermissionsRequired -childApp $webApp -spForApp $spWebApp
                
                # WebAPI permission
                $appPermissionsRequired = @('user_impersonation')
                #$targetServicePrincipalName = $webApiName
                $targetServicePrincipalAppId=$webApi.AppId
                #$apiAad = GrantAllThePermissionsWeWant -targetServicePrincipalName $targetServicePrincipalName -appPermissionsRequired $appPermissionsRequired -childApp $webApp -spForApp $spWebApp
                $apiAad = GrantAllThePermissionsWeWant -targetServicePrincipalAppId $targetServicePrincipalAppId -appPermissionsRequired $appPermissionsRequired -childApp $webApp -spForApp $spWebApp
               
                $permission = @($msGraphAad,$apiAad)
                Set-AzureADApplication -ObjectId $webApp.ObjectId -RequiredResourceAccess $permission
                
                Write-Verbose "$(Get-TimeStamp)Checking resource deployment template..." #-ForegroundColor $([Constants]::MessageType.Info)
                
                $validationResult = Test-AzResourceGroupDeployment -Mode Incremental -ResourceGroupName $ScanHostRGName -TemplateFile $TemplateFilePath -TemplateParameterObject $TemplateParameters 
                if($validationResult)
                {
                    Write-Host "`n`rTemplate deployment validation returned following errors:" -ForegroundColor $([Constants]::MessageType.Error)
                    $validationResult | FL Code, Message;
                    return;
                }
                else
                {
                    # Deploy template
                    $deploymentName = "AzTSenvironmentsetup-$([datetime]::Now.ToString("yyyymmddThhmmss"))"
                    $deploymentResult = New-AzResourceGroupDeployment -Name $deploymentName -Mode Incremental -ResourceGroupName $ScanHostRGName -TemplateFile $TemplateFilePath -TemplateParameterObject $TemplateParameters  -ErrorAction Stop -verbose 
                    Write-Verbose "$(Get-TimeStamp)Completed resources deployment for azure tenant security solution."
                
                    #Update App registered in AAD
                    #Web App
                    if($deploymentResult.Outputs.ContainsKey('webAppName') -and $deploymentResult.Outputs.ContainsKey('webApiName'))
                    {
                        $azureWebAppName= $deploymentResult.Outputs.webAppName.Value
                        $azureWebApiName= $deploymentResult.Outputs.webApiName.Value
                        
                        $identifierUri = 'api://{0}' -f $webApp.AppId
                        $replyUris = New-Object Collections.Generic.List[string]
                        $replyUris.Add(('https://{0}.azurewebsites.net' -f $azureWebAppName));
                        $replyUris.Add(('https://{0}.azurewebsites.net/auth.html' -f $azureWebAppName));
                        Set-AzureADApplication -ObjectId $webApp.ObjectId -ReplyUrls $replyUris -IdentifierUris $identifierUri -Oauth2AllowImplicitFlow $true
                        
                        $apiUri = "https://$azureWebApiName.azurewebsites.net/"
                        $webAppZipUrl = "https://azskaztsdataring0.blob.core.windows.net/azsk-ats-packages/WebApp/Latest/WebApp.1.0.33.zip"
                        
                        Configure-WebUI -TenantId $context.Tenant.Id -ScanHostRGName $ScanHostRGName -WebAppName $azureWebAppName -ApiUrl $apiUri -WebAppClientId $webApp.AppId -WebApiClientId $webApi.AppId
                    
                        $identifierUri = 'api://{0}' -f $webApi.AppId
                        Set-AzureADApplication -ObjectId $webApi.ObjectId -IdentifierUris $identifierUri -Oauth2AllowImplicitFlow $true

                    }
                }                
            }
            catch
            {
                Write-Host "`rTemplate deployment returned following errors: [$($_)]." -ForegroundColor $([Constants]::MessageType.Error)
                return;
            }

            # Post deployment steps
            Write-Verbose "$(Get-TimeStamp)Starting post deployment environment steps.." 
            try
            {
                # Check if queue exist; else create new queue
                $storageAccountName = [string]::Empty;
                $storageQueueName = [string]::Empty;
                Write-Verbose "$(Get-TimeStamp)Creating Storage queue to queue the subscriptions for scan.." #-ForegroundColor $([Constants]::MessageType.Info)
                if( $deploymentResult.Outputs.ContainsKey('storageId') -and $deploymentResult.Outputs.ContainsKey('storageQueueName'))
                {
                    $storageAccountName = $deploymentResult.Outputs.storageId.Value.Split("/")[-1]
                    $storageQueueName = $deploymentResult.Outputs.storageQueueName.Value
                    $storageAccountKey = Get-AzStorageAccountKey -ResourceGroupName $ScanHostRGName -Name $storageAccountName -ErrorAction Stop
                    if(-not $storageAccountKey)
                    {
                        throw [System.ArgumentException] ("Unable to fetch 'storageAccountKey'. Please check if you have the access to read storage key.");
                    }
                    else
                    {
                        $storageAccountKey = $storageAccountKey.Value[0]
                    }

                    $storageContext = New-AzStorageContext -StorageAccountName $storageAccountName  -StorageAccountKey $storageAccountKey -ErrorAction Stop
                    $storageQueue = Get-AzStorageQueue -Name $storageQueueName -Context $storageContext -ErrorAction SilentlyContinue
                    if(-not $storageQueue)
                    {   
                        $storageQueue = New-AzStorageQueue -Name $storageQueueName -Context $storageContext -ErrorAction Stop
                    }
                }
                else
                {
                    Write-Host "Failed to create Storage queue." -ForegroundColor $([Constants]::MessageType.Error)
                    return
                }

                Write-Host "`rCompleted installation for Azure Tenant Security Solution." -ForegroundColor $([Constants]::MessageType.Update)
                Write-Host "$([Constants]::DoubleDashLine)" #-ForegroundColor $([Constants]::MessageType.Info)
                Write-Host "$([Constants]::NextSteps)" -ForegroundColor $([Constants]::MessageType.Info)
                Write-Host "$([Constants]::DoubleDashLine)"
            }
            catch
            {
                Write-Host "Error occured while executing post deployment steps. ErrorMessage [$($_)]" -ForegroundColor $([Constants]::MessageType.Error)
            }
        }
}

class Constants
{
    static [Hashtable] $MessageType = @{
        Error = [System.ConsoleColor]::Red
        Warning = [System.ConsoleColor]::Yellow
        Info = [System.ConsoleColor]::Cyan
        Update = [System.ConsoleColor]::Green
	    Default = [System.ConsoleColor]::White
    }

    static [string] $InstallSolutionInstructionMsg = "This command will perform 3 important operations. It will:`r`n`n" + 
					"   [1] Create resources needed to support Azure Tenant Security scan `r`n" +
                    "   [2] Deploy AzTS packages to azure function app `r`n" +
					"   [3] Deploy UI and API packages to respective azure web service apps `r`n" +
                    "   [4] Schedule daily subscription scan `r`n`n" +
                    "More details about resources created can be found in the link: http://aka.ms/DevOpsKit/TenantSecuritySetup `r`n"
    static [string] $DoubleDashLine    = "================================================================================"
    static [string] $SingleDashLine    = "--------------------------------------------------------------------------------"
    
    static [string] $NextSteps = "** Next steps **`r`n" + 
    "        a) You can trigger scan manually as described in 'Steps to trigger the functions' of 'Verifying that Tenant Security Solution installation is complete' section of AzTS Docs.`r`n"+
    "        b) After scan completion, All security control results will be sent to LA workspace and Storage account present in your hosting subscription scan RG.`r`n" +
    "        c) Using the AzTS UI you can monitor all the compliance detail of the controls for all the subscriptions you have scanned in step a. or you can trigger new adhoc scan for subscriptions of your choice throug UI itself and monitor new compliance details.`r`n"+
    "        d) You can create compliance monitoring Power BI dashboard using link: http://aka.ms/DevOpsKit/TenantSecurityDashboard .`r`n" +
    "        e) For any feedback contact us at: azsksup@microsoft.com .`r`n"+
    "              ** OR  **`r`n"+
    "        a) Azure Tenant security scan will start on scheduled time (UTC 00:00).`r`n" +
    "        b) After scan completion, All security control results will be sent to LA workspace and Storage account present in your hosting subscription scan RG.`r`n" +
    "        c) Using the AzTS UI you can monitor all the compliance detail of the controls for all the subscriptions which were scanned through step a. or you can trigger new adhoc scan for subscriptions of your choice throug UI itself and monitor new compliance details.`r`n"+
    "        d) You can create compliance monitoring Power BI dashboard using link: http://aka.ms/DevOpsKit/TenantSecurityDashboard .`r`n" +
    "        e) For any feedback contact us at: azsksup@microsoft.com .`r`n"
}

class ContextHelper
{
    $currentContext = $null;

    [PSObject] SetContext([string] $SubscriptionId)
    {
            $this.currentContext = $null
            if(-not $SubscriptionId)
            {

                Write-Host "The argument 'SubscriptionId' is null. Please specify a valid subscription id." -ForegroundColor $([Constants]::MessageType.Error)
                return $null;
            }

            # Login to Azure and set context
            try
            {
                if(Get-Command -Name Get-AzContext -ErrorAction Stop)
                {
                    $this.currentContext = Get-AzContext -ErrorAction Stop
                    $isLoginRequired = (-not $this.currentContext) -or (-not $this.currentContext | GM Subscription) -or (-not $this.currentContext | GM Account)
                    
                    # Request login if context is empty
                    if($isLoginRequired)
                    {
                        Write-Host "No active Azure login session found. Initiating login flow..." -ForegroundColor $([Constants]::MessageType.Warning)
                        $this.currentContext = Connect-AzAccount -ErrorAction Stop # -SubscriptionId $SubscriptionId
                    }
            
                    # Switch context if the subscription in the current context does not the subscription id given by the user
                    $isContextValid = ($this.currentContext) -and ($this.currentContext | GM Subscription) -and ($this.currentContext.Subscription | GM Id)
                    if($isContextValid)
                    {
                        # Switch context
                        if($this.currentContext.Subscription.Id -ne $SubscriptionId)
                        {
                            $this.currentContext = Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop -Force
                        }
                    }
                    else
                    {
                        Write-Host "Invalid PS context. ErrorMessage [$($_)]" -ForegroundColor $([Constants]::MessageType.Error)
                    }
                }
                else
                {
                    Write-Host "Az command not found. Please run the following command 'Install-Module Az -Scope CurrentUser -Repository 'PSGallery' -AllowClobber -SkipPublisherCheck' to install Az module." -ForegroundColor $([Constants]::MessageType.Error)
                }
            }
            catch
            {
                Write-Host "Error occured while logging into Azure. ErrorMessage [$($_)]" -ForegroundColor $([Constants]::MessageType.Error)
                return $null;
            }

            return $this.currentContext;
    
    }
    
}

function Get-TimeStamp {
    return "{0:h:m:s tt} - " -f (Get-Date)
}

Function CreateChildApp
{
    param (
        [string] $displayName
    )
    if (!(Get-AzureADApplication -SearchString $displayName)) {
        # create new application
        $app = New-AzureADApplication -DisplayName $displayName 

        # create a password (spn key)
        #$appPwd = New-AzureADApplicationPasswordCredential -ObjectId $app.ObjectId
        #$appPwd

        # create a service principal for your application
        # you need this to be able to grant your application the required permission
        $spForApp = New-AzureADServicePrincipal -AppId $app.AppId #-PasswordCredentials @($appPwd) 
        
    }
    else{
        $app = Get-AzureADApplication -SearchString $displayName
    }
    #endregion
    return $app
}

function GrantAllThePermissionsWeWant
{
    #[OutputType([Microsoft.Open.AzureAD.Model.RequiredResourceAccess])]
    param
    (
        [string] $targetServicePrincipalAppId,
        $appPermissionsRequired,
        $childApp,
        $spForApp
    )

    $targetSp = Get-AzureADServicePrincipal -Filter "AppId eq '$($targetServicePrincipalAppId)'"

    $RoleAssignments = @()
    Foreach ($AppPermission in $appPermissionsRequired) {
        $RoleAssignment = $targetSp.Oauth2Permissions | Where-Object { $_.Value -eq $AppPermission}
        $RoleAssignments += $RoleAssignment
    }

    $ResourceAccessObjects = New-Object 'System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.ResourceAccess]'
    foreach ($RoleAssignment in $RoleAssignments) {
        $resourceAccess = New-Object -TypeName "Microsoft.Open.AzureAD.Model.ResourceAccess"
        $resourceAccess.Id = $RoleAssignment.Id
        $resourceAccess.Type = 'Scope'
        $ResourceAccessObjects.Add($resourceAccess)
    }
    $requiredResourceAccess = New-Object -TypeName "Microsoft.Open.AzureAD.Model.RequiredResourceAccess"
    $requiredResourceAccess.ResourceAppId = $targetSp.AppId
    $requiredResourceAccess.ResourceAccess = $ResourceAccessObjects

    # grant the required resource access
    #foreach ($RoleAssignment in $RoleAssignments) {
    #    Write-Output -InputObject ('Granting admin consent for App Role: {0}' -f $($RoleAssignment.Value))
    #    New-AzureADServiceAppRoleAssignment -ObjectId $spForApp.ObjectId -Id $RoleAssignment.Id -PrincipalId $spForApp.ObjectId -ResourceId $targetSp.ObjectId
    #    Start-Sleep -s 1
    #}

    return $requiredResourceAccess
    
}

function get-hash([string]$textToHash) {
    $hasher = new-object System.Security.Cryptography.MD5CryptoServiceProvider
    $toHash = [System.Text.Encoding]::UTF8.GetBytes($textToHash)
    $hashByteArray = $hasher.ComputeHash($toHash)
    foreach($byte in $hashByteArray)
    {
      $result += "{0:X2}" -f $byte
    }
    return $result;
 }


function GrantGraphPermissionToUserAssignedIdentity
{
    Param
    (
        [string]
        [Parameter(Mandatory = $true, HelpMessage="Object id of user managed identity used to scan subscriptions.")]
        $ScanIdentityObjectId
    )

    try {
        $graph = Get-AzureADServicePrincipal -Filter "AppId eq '00000003-0000-0000-c000-000000000000'"
        $groupReadPermission = $graph.AppRoles `
            | where Value -Like "PrivilegedAccess.Read.AzureResources" `
            | Select-Object -First 1
        
        $msi = Get-AzureADServicePrincipal -ObjectId $ScanIdentityObjectId
        
        New-AzureADServiceAppRoleAssignment `
        -Id $groupReadPermission.Id `
        -ObjectId $msi.ObjectId `
        -PrincipalId $msi.ObjectId `
        -ResourceId $graph.ObjectId
    }
    catch {
        Write-Error $_.Exception.Message
        Write-Host "[Warning]: To grant Graph API permission, the signed-in user must be a member of one of the following administrator roles: Global Administrator, Security Administrator, Security Reader or User Administrator."  -ForegroundColor Yellow 
    }   
}

