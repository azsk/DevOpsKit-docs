# Standard configurations
# Link to the Azure Active Directory Authentication URL, ending with a '/'. Example: https://login.microsoftonline.com/
$AzureAdAuthUrl = "https://login.microsoftonline.com/"

# Link to the Graph API endpoint. Example: https://graph.microsoft.com
$GraphApi = "https://graph.microsoft.com"

# Link to a page, where issues seen in AzTS can be reported to the dev. team.
# This will refer to the Issues page for "DevOpsKit-docs", till the AzTS code is made available for public use.
$IssueTrackerUrl = "https://github.com/azsk/DevOpsKit-docs/issues"

# AzTS Support Mail
$IssueSupportMail = "mailto:aztssup@microsoft.com"

# Default Baseline
$DefaultBaseline = "ActiveBaseline"

# Base URL to the Wiki, that has information about Controls and their remediation steps.
# Currently, there is an expecation that all such URLs are of the form - BaseURL/ControlName. Example: https://foo.bar/ControlName
$ControlWikiBaseUrl = "https://foo.bar/"

# Exception configurations
# A string indicating if support for raising exceptions to Controls, is available. "false", by default.
$IsExceptionsEnabled = "false"

# Link to a portal where non - "ByDesign" exceptions can be raised and tracked for compliance. 
$DefaultExceptionsTarget = "<replace-with-a-link-to-the-compliance-portal>"

# User impersonation configurations
# A string indicating if support for User Impersonation, is available. "false", by default.
$IsUserImpersonationEnabled = "false"

# User impersonation endpoint, beginning with a '/'. Example: /user_impersonation
$UserImpersonationEndpoint = "<replace-with-a-link-to-the-user-impersonation-endpoint>"

function Configure-WebUI
{
    Param(
        [string]
        [Parameter(Mandatory = $true, HelpMessage="TenantID of the subscription where Azure Tenant Security Solution is to be installed.")]
        $TenantId,

        [string]
        [Parameter(Mandatory = $true, HelpMessage="Name of the Resource Group where setup resources will be created.")]
        $ScanHostRGName,

        [string]
        [Parameter(Mandatory = $true, HelpMessage="Name of the web app deployed in azure for Azure Tenant Security Solution.")]
        $UIAppName,

        [string]
        [Parameter(Mandatory = $true, HelpMessage="URL of the Web API")]
        $ApiUrl,

        [string]
        [Parameter(Mandatory = $true, HelpMessage="ClientId of the web app deployed in azure for Azure Tenant Security Solution.")]
        $UIClientId,

        [string]
        [Parameter(Mandatory = $true, HelpMessage="ClientId of the web api deployed in azure for Azure Tenant Security Solution.")]
        $WebApiClientId
    )

    Write-Host "Updating UI web app configuration..."
    
    $baseDir = Get-Location
    $configFile = "runtime-configuration.js"
    $configFilePath = "${baseDir}\${configFile}"
    $configJs = @"
window.__REACT_APP_RUNTIME_CONFIGURATION__ = {
    "tenantId": "$TenantId",
    "webAPI": "$ApiUrl",
    "clientId": "$UIClientId",
    "apiClientId": "$WebApiClientId/",
    "azureADAuthURL": "$AzureAdAuthUrl",
    "graphAPI": "$GraphApi",
    "issueTrackerURL": "$IssueTrackerUrl",
    "issueSupportMail": "$IssueSupportMail",
    "defaultBaseline": "$DefaultBaseline",
    "controlWikiBaseURL": "$ControlWikiBaseUrl",
    "Baselines": [
        {
            "name": "foo",
            "controlFilterLabel": "Foo Baseline Controls Only",
            "isControlFilterToggleEnabled": true,
            "isExceptionsEligible": true,
            "exceptionTarget": "mailto:xyz@foo.bar?subject=Request a New Foo Exception",
        },
        {
            "name": "bar",                
            "isExceptionsEligible": true,
        },
    ],
    "Exceptions": {
        "isEnabled": $IsExceptionsEnabled,
        "defaultExceptionTarget": "$DefaultExceptionsTarget",
        "CustomType": {
            "key": "<name-of-the-exception>",
            "text": "<name-of-the-exception>",
            "data": "<name-of-the-exception>",
            "disabled": false            
        }
    },
    "UserImpersonation": {
       	"isEnabled": $IsUserImpersonationEnabled,
        "endpoint": "$UserImpersonationEndpoint"
    }
}
"@

    $configJs | Set-Content $configFilePath

    $webApp = Get-AzWebApp -Name $UIAppName -ResourceGroupName $ScanHostRGName
    [xml]$publishingProfile = Get-AzWebAppPublishingProfile -WebApp $webApp
    $username = $publishingProfile.publishData.publishProfile[0].userName
    $password = $publishingProfile.publishData.publishProfile[0].userPWD
    $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $username, $password)))
    $userAgent = "powershell/1.0"
    
    $uploadUrl = "https://${UIAppName}.scm.azurewebsites.net/api/vfs/site/wwwroot/${configFile}"
    Invoke-RestMethod -Uri $uploadUrl -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -UserAgent $userAgent -Method PUT -InFile $configFilePath -ContentType "multipart/form-data"

    Reset-AzWebAppPublishingProfile -Name $UIAppName -ResourceGroupName $ScanHostRGName
    
    If((test-path $configFilePath))
    {
        Remove-Item -Force -Path $configFilePath
    }
}